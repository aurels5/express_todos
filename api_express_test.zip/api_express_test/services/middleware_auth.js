const jwt = require('jsonwebtoken')
const express = require('express')
const config = { privateKey: "TopSecret" }
const Signin = require('../models/signin')

module.exports = {
  generateToken (payload) {
    return jwt.sign(payload, config.privateKey, {
      expiresIn: '1 hour'
    })
  },
  generateCookie (res, req, token) {
    let options = {
      maxAge: 1000 * 60 * 15,
      httpOnly: true,
      // signed: true
    }
    return res.cookie('accessToken', token, options)
  },
  checkCookie (req, res, next) {
    if (!req.cookies.accessToken) return res.redirect('/signin') // Si pas de cookie accessToken on revient sur l'authentification
    jwt.verify(req.cookies.accessToken, config.privateKey, (err, decode) => {
      //console.log("token décodé : ", decode)
      if(decode){ // payload ? Parfois il n'existe plus mais le verify capte pas..
        if (new Date().getTime() / 1000 <= decode.exp) { // && decode.id == req.params.userId
          next()
        } else {
          console.log('Connectez-vous au bon User pour le modifier')
          return res.redirect('/signin')
        }
      } else {//donc si decode n'existe pas --> erreur
        Signin.deleteToken(req.cookies.accessToken)
        return res.redirect('/signin')
      }
    })
  }
}//end module.exports
