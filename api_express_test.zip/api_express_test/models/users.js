//Users Model

const db = require('sqlite')
const _ = require('lodash')
const bcrypt = require('bcrypt')

module.exports = {
  //POST, on attend un status 201
  async create(params) {
    try{
      delete params.save
      let d = new Date()
      let mois = d.getMonth()+1
      params.createdAt = d.getDate() + "/"+ mois + "/"+ d.getFullYear()
      params.updatedAt = null
      params.tempPassword = bcrypt.hashSync(params.pwd, 10)
      //on delete ce con qui se met avant nos createdAt et updatedAt comme on le récupère avant dans la vue
      delete params.pwd

      //console.log("TOUS LES PARAMS : ",params)
      const data = _.values(params)
      //console.log("Modèle users, create data : ",data)

      await db.run("INSERT INTO users VALUES(?,?,?,?,?,?,?,?,?) ", data )
    } catch(err){
      console.log("Erreur lors de l'insert de l'user : ", err, "\n avec les params ", params)
    }
  },

  //GET
  async read(idUser){
    try{
      if(idUser){ //if we GET 1 user by id
        let monUser=null
        monUser = await db.each("SELECT * FROM users WHERE id="+idUser)
        return await monUser
      }else{ //if we GET ALL users
        let mesUsers=null
        mesUsers = await db.all("SELECT * FROM users")
        return await mesUsers
      }
    } catch(err){
      console.log("Erreur lors du get du ou des user(s) : ", err)
    }
  },//fin du read

  //db.get('SELECT * FROM `users` WHERE pseudo = ?', req.body.pseudo
  //GET by pseudo
  async readByPseudo(pseudoUser){
    try{
      if(pseudoUser){
        //console.log("models/users.js pseudoUser : ", pseudoUser)
        let monUser=null
        monUser = await db.get('SELECT * FROM `users` WHERE pseudo = ?', pseudoUser)
        //console.log("monUser : ", monUser)
        return await monUser
      }
    } catch(err){
      console.log("Erreur lors du get du user par pseudo : ", err)
    }
  },//fin du read

  //UPDATE
  update(params,id){
    try{
      console.log("On passe dans l'update du user ",id)

      delete params.save

      let d = new Date()
      let mois = d.getMonth()+1
      params.updatedAt = d.getDate() + "/"+ mois + "/"+ d.getFullYear()
      params.id = id

      params.tempPassword = bcrypt.hashSync("pcoucoud", 10)
      delete params.pwd //pour l'ordre, on remet le tempPwd en dernier
      const data = _.values(params) //construit le tableau de values avec le req.body du ctrl
      console.log("data du lodash : ",data)

      db.run("UPDATE users SET pseudo=?, email=?, firstname=?, lastname=?, updatedAt=?, teamId=?, pwd=? WHERE id=?", data )
    } catch(err){
      console.log("Erreur lors de l'update de l'user : ", err, "\n dont l'id est ", id)
    }
  },

  //DELETE
  delete(id){
    try{
      db.open('bdd_express.db')
      //db.run("DELETE FROM users WHERE _rowid_="+id) //OK mais supprime la dernière ligne ! O_O
      console.log("Model : DELETE FROM users WHERE id="+id)

      db.run("DELETE FROM users WHERE id=?", id, (err) => {
        if (err) {
          return console.error(err.message);
        }
        console.log(`Row(s) deleted ${this.changes}`)
      })
      db.close()

      //return await del
    }catch(err){
      console.log("Erreur lors du delete du user donc l'id est ", id, " : ", err)
    }
  },


} //end module.exports model users
