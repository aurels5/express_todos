//Signin Model
const db = require('sqlite')
const _ = require('lodash')
const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')

module.exports = {
  async createToken(userId, token) {
    try{
      // On décode le token
      tokenDecoded = jwt.decode(token)
      const params = {}
      params.userId = userId
      params.accessToken = token
      //console.log("token : ", token)
      params.createdAt = tokenDecoded.iat
      params.expiresAt = tokenDecoded.exp
      //console.log("Modèle signin, create params : ", params)
      const data = _.values(params)
      //console.log("Modèle signin, create data : ", data);
      await db.run("INSERT INTO sessions VALUES(?,?,?,?) ", data)
      console.log('token bien créé')
    } catch(err){
      console.log("Erreur lors de l'insert de la session : ", err)
    }
  },

  //DELETE
  deleteToken(accessToken){
    try{
      db.open('bdd_express.db')
      console.log("Model : DELETE FROM sessions WHERE accessToken LIKE"+accessToken)

      db.run("DELETE FROM sessions WHERE accessToken LIKE ?", accessToken, (err) => {
        if (err) {
          return console.error(err.message);
        }
        console.log(`Row(s) deleted ${this.changes}`)
      })
      db.close()

      //return await del
    }catch(err){
      console.log("Erreur lors du delete de la session dont l'accessToken est ", accessToken, " : ", err)
    }
  }

}
