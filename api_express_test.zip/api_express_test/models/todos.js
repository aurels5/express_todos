//Signin Model
const db = require('sqlite')
const _ = require('lodash')

module.exports = {
  async createTodo(params,userId) {
    try{
      delete params.save
      //we get title and message from view before
      params.userId = userId

      let d = new Date()
      let mois = d.getMonth()+1
      params.createdAt = d.getDate() + "/"+ mois + "/"+ d.getFullYear()
      params.updatedAt = null
      params.completedAt = null //quand il a fini la vaisselle !

      const data = _.values(params) //data = tableau fait avec lodash depuis l'objet params

      await db.run("INSERT INTO todos VALUES(?,?,?,?,?,?,?,?) ", data) //on a compté l'id
    } catch(err){
      console.log("Erreur lors de l'insert de la todo : ", err, " avec data : ", _.values(params))
    }

  },

  async readTodosOfUser(userId){
    try {
      let mesTodos = null

      let teamObject = null
      try {
        let teamObject = await db.each("SELECT teamId FROM users WHERE id=" + userId)

        if(!teamObject){
          console.log("On n'a pas de team !")
          //l'user ne peut voir que ses todos
          mesTodos = await db.all("SELECT * FROM todos WHERE userId=" + userId +" ORDER BY completedAt")
        } else {
          //console.log("On est dans la team ", teamObject.teamId)
          teamId = teamObject.teamId
          //requête imbriquée, il voit toutes les todos des users de la team
          mesTodos = await db.all("SELECT * FROM todos WHERE userId IN (SELECT id FROM users WHERE teamId= "+ teamId +") ORDER BY completedAt ")
        }

      } catch(e){
        console.log("Model Todos erreur recherche idTeam : ",e.toString())
      }

      return await mesTodos
    } catch(err){
      console.log("Erreur lors du get de la ou des todo(s) : ", err)
    }
  },

  async onCompleteChecked(idTodo){
    console.log("Todos Model onCompleteChecked called : let's save task as completedAt")
    //save task as completedAt
    let d = new Date()
    let day = d.getDate()
    let month = d.getMonth()+1
    let hour = d.getHours()
    let minutes = d.getMinutes()

    let completedAt = day + "/" + month + " at " + hour + "h" + minutes

    await db.run("UPDATE todos SET completedAt = ? WHERE id=?" , [completedAt,idTodo])
  }
}//fin module.exports
