const express = require('express')
const app = express()
const bcrypt = require('bcrypt')
const db = require('../db')
const { generateToken, generateCookie } = require('../services/middleware_auth')
const Signin = require('../models/signin')
const Users = require('../models/users')

//Get view signin : GET /signin
app.get('', (req, res, next)=>{
  console.log('/get Sign in...')
  let myActionSignin = "/signin"
  let pageTitle = "Sign in !"
  res.render('sessions/signin', { pageTitle: pageTitle, myActionForm: myActionSignin } )
});


app.post('', async (req, res, next) => {
  //console.log("pseudo : ", req.body.pseudo, "...et pwd : ", req.body.pwd)

  if (!(req.body.pseudo && req.body.pwd)) { //OK!
    console.log("signinCtrl says : Tous les champs n'ont pas été remplis")
    return next(new Error('Remplis tous les champs crétinus. сын твоей мама'))
  }

  try {
    //console.log('Le await est mort')
    let existingUser = await Users.readByPseudo(req.body.pseudo)
    //console.log('existingUser : ', existingUser)
    let pwdConfirm = bcrypt.compareSync(req.body.pwd, existingUser.pwd)
    //console.log("On passe dans le try du signinController... pwdConfirm : ", pwdConfirm)
    if (pwdConfirm) { //l'user et son mdp sont valides dans la db
      let token = generateToken({ id: existingUser.id })
      Signin.createToken(existingUser.id, token)
      console.log('OK ON TE CO!')
      generateCookie(res, req, token)
    } else {
      throw err = new Error('Mot de passe incorrect')
    }
    res.format({
      html: ()=> res.redirect("/todos"),
      json: ()=> res.status(201).send({message: 'success'})
    })

  } catch (err) {
    next(err.toString())
    res.format({
      html: ()=> res.redirect("/signin"),
      json: ()=> res.status(400).send({message: err.toString()})
    })
  }
})

app.delete('', (req, res, next) => {

})


module.exports = app
