const router = require('express').Router()
const { checkCookie } = require('./../services/middleware_auth')
const jwt = require('jsonwebtoken')
//const Users = require('./../models/users')
const Todos = require('./../models/todos')
//const { onCheck } = require('../services/todosScripts')

//Get view add to add a todo (view of POST)
router.get('/add', checkCookie, (req, res, next) => {           //OK!
  console.log('Getting template to add a todo')
  let myActionAdd = "/todos/add"
  let titrePage = "Add a todo"
  res.render('todos/edit', {titrePage: titrePage, myActionForm: myActionAdd})
})

//Get view edit to edit (PUT) a particular todo
router.get('/:userId/edit', checkCookie, async (req, res, next)=>{
  let userId = req.params.userId
  let todoToUpdate = await Todos.read(todoId)
  let myUpdateAction = "/todos/" + todoId + "?_method=put"
  console.log("Edit todo : ", todoToUpdate)
  let titrePage = "Update todo"
  res.render('todos/edit', {titrePage: titrePage, myActionForm: myUpdateAction, u: userToUpdate})
})

//Ajouter un todo
router.post('/add', (req, res, next) => {  // /users/:userId
  //get user by token
  let token = req.cookies.accessToken
  tokenDecoded = jwt.decode(token)
  let idUser = tokenDecoded.id

  console.log('On POST la todo... avec l\'user... on verra !')
  Todos.createTodo(req.body, idUser) //params
  res.format({
    html: ()=> res.redirect("/todos"),
    json: ()=> res.status(201).send({message:'success'})
  })
})

//Set todo as completed with completedAt
router.post('/', (req, res, next) => {
  //avec req.body.letruc on récupère la value de l'input name=letruc
  console.log("id cliqué... ",req.body.id)
  let bodyIdClicked = req.body.id

  Todos.onCompleteChecked(bodyIdClicked) //id de la Todo à récupérer
  res.format({
    html: ()=> res.redirect("/todos"),
    json: ()=> res.status(201).send({message:'success'})
  })
})

//Lister tous les todos du user
router.get('', checkCookie, async (req, res) => {
    console.log("GET /todos")

    let token = req.cookies.accessToken
    tokenDecoded = jwt.decode(token)
    let idUser = tokenDecoded.id
    mesTodos = await Todos.readTodosOfUser(idUser)
    let myActionAdd = "/todos"
    //console.log(mesTodos) //affiche tous les users
    res.render('todos/show', { lesTodos: mesTodos, myActionForm: myActionAdd } )
})


//Éditer une todo PUT /todos/:idUser/:idTodo
router.put('/:userId', checkCookie, function (req, res) {
  let userId = req.params.userId
  console.log("On rentre dans le PUT /users/:userId=",userId)
  Users.update(req.body,userId)
  res.format({
    html: ()=> res.redirect("/users/"+userId),
    json: ()=> res.status(201).send({message:'success'})
  })
  //res.status(200).send('PUT /users/:userId=' + userId)
})

//Supprimer une todo
router.delete('/:id', (req, res, next) => {
    let id = req.params.id
    console.log("Ctrl delete id=",id)
    Users.delete(id) //let del = await
    //res.redirect('')
    res.format({
      html: ()=> res.redirect("/users"),
      json: ()=> res.status(200).send({message:'success'})
    })
})


module.exports = router
