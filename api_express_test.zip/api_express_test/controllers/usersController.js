const router = require('express').Router()
const Users = require('./../models/users')
const { checkCookie } = require('./../services/middleware_auth')

//Get view add to add (POST) a user, users/add
router.get('/add', (req, res, next)=>{
  //console.log('Getting template to add a user')
  let myActionAdd = "/users"
  let titrePage = "Add user"
  res.render('users/edit', {titrePage: titrePage, myActionForm: myActionAdd})
})

//Get view edit to edit (PUT) a particular user
router.get('/:userId/edit', checkCookie, async (req, res, next)=>{
  let userId = req.params.userId
  let userToUpdate = await Users.read(userId)
  let myUpdateAction = "/users/" + userId + "?_method=put"
  //console.log("Edit user : ", userToUpdate)
  let titrePage = "Update user"
  res.render('users/edit', {titrePage: titrePage, myActionForm: myUpdateAction, u: userToUpdate})
})

//Ajouter un utilisateur, POST /users
router.post('/', (req, res, next)=>{  // /users/:userId
  console.log('On POST l\'user /users/userId')
  Users.create(req.body)
  res.format({
    html: ()=> res.redirect("/users"),
    json: ()=> res.status(201).send({message: 'success'})
  })
})

//Lister tous les utilisateurs
//GET /users?limit=20&offset=0
router.get('', async (req, res) => {
    console.log("GET /users")
    mesUsers = await Users.read()
    //console.log(mesUsers) //affiche tous les users
    res.render('users/show', { lesUsers: mesUsers })
})

//Récupérer un utilisateur by id, GET /users/:userId
router.get('/:userId', async (req, res) => {
    //let idUser = req.url.split("/")[1]
    let idUser = req.params.userId
    console.log("GET userId=",idUser)

    let monUser = await Users.read(idUser)
    //console.log("monUser : " monUser)

    let titrePage = "GET l'user : " + idUser
    let myActionDelete = idUser + "?_method=DELETE"

    res.render('users/showUser', {'titrePage': titrePage, 'leUser': monUser, 'myActionDelete': myActionDelete})
})

//Éditer un utilisateur PUT /users/:userId
router.put('/:userId', checkCookie, function (req, res) {
  let userId = req.params.userId
  //console.log("On rentre dans le PUT /users/:userId=", userId)
  Users.update(req.body,userId)
  res.format({
    html: ()=> res.redirect("/users/"+userId),
    json: ()=> res.status(201).send({message: 'success'})
  })
  //res.status(200).send('PUT /users/:userId=' + userId)
})

//Supprimer un utilisateur DELETE /users/:userId
router.delete('/:id', checkCookie, (req, res, next) => {
    let id = req.params.id
    //console.log("Ctrl delete id=",id)
    Users.delete(id) //let del = await
    //res.redirect('')
    res.format({
      html: ()=> res.redirect("/users"),
      json: ()=> res.status(200).send({message:'success'})
    })
})


module.exports = router
