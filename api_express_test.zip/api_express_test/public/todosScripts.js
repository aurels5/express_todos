console.log('todosScript running');

document.addEventListener("DOMContentLoaded", function(event) {
  const buttons = document.getElementsByClassName('checkboxTodo');
  let nbButtons = buttons.length
  for (let i = 0; i < nbButtons ; i++) {
    //console.log("button : ", buttons[i])
    buttons[i].addEventListener('click', function(e) {
      let myBtn = this
      let myBtnValue = myBtn.value
      console.log('button ', i,' was clicked with id ', myBtnValue);
      if(myBtn){//sometimes already done
        myBtn.innerHTML = "Done"
        myBtn.id = "done" + myBtnValue
        req.send({ id: myBtnValue })
      }
    })
  }
})
