//npm install componentName
const express = require('express')
const bodyParser = require('body-parser')
const app = express()
const PORT = process.env.PORT || 8080
const myDb = require('./db')
const hbs = require('hbs') //handlebars
//hbs.handlebars === require('handlebars');
const handlebars = hbs.handlebars // hbs.handlebars is the handlebars' module
const formHelpers = require('handlebars-form-helpers')
const cookieParser = require('cookie-parser')
const path = require('path')

const methodOverride = require('method-override') //allows PUT and DELETE while overriding with POST having ?_method=DELETE
app.use(methodOverride('_method'))

formHelpers.register(hbs.handlebars)

//CSS
app.use('/static',express.static(path.join(__dirname, 'public/styles')))
app.use('/static',express.static(path.join(__dirname, 'public')))

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }))
// parse application/json
app.use(bodyParser.json())
app.use(cookieParser())

//Using our emplate generator
//app.set('view engine', 'hbs'); //generates .hbs for our res.render()
app.set('view engine', 'html');
app.engine('html', require('hbs').__express);

//hbs.registerHelper('helper_name', function(...) { ... });
//hbs.registerPartial('partial_name', 'partial value');
//registerPartials provides a quick way to load all partials from a specific directory:
//hbs.registerPartials(__dirname + '/views/partials' [, callback]);

hbs.localsAsTemplateData(app);
app.locals.titreApp = "Mon Application";


//GESTION DES ROUTES--------------------------------------
//app.use('/api')
//tout ce qui est dans le usersController commencera par la route '/users'
app.use('/users', require('./controllers/usersController'))
app.use('/signin', require('./controllers/signinController'))
app.use('/todos', require('./controllers/todosController'))

app.all('*',(req, res, next)=>{
  console.log('ALL("*") is called')
  next()
})

app.get('/', (req, res, next) => {
  return res.format({
    html: () => {
      if (req.cookies && req.cookies.accessToken) {
        //return res.redirect('/users')
        return res.redirect('/todos')
      }
      res.redirect('/signin')
    },
    json: () => { res.send({ message: 'Bienvenue sur notre superbe API!' }) }
  })
})

/*
app.get('/', function(req, res) {
    res.setHeader('Content-Type', 'text/html');

    let contributeurA = {
      'surname' : "Aurélia",
      'name' : "Sarradin",
      'age' : 23
    }

    let contribTitle = "Les contributeurs"
    let currentDate = new Date()
    let googleAge = currentDate.getFullYear()-1998

    let listeContributeurs =
      [
        {
          surname : "Aurélia",
          name : "Sarradin",
          age : 23
        },
        {
          surname : "Tanguy",
          name : "Bouchet",
          age : "23 MAINTENANT !! mais moins dans la tête"
        },
        {
          surname : "Google",
          name : "Le meilleur ami du dev !",
          age : googleAge
        }
      ];

    //console.log('listeContributeurs : ',listeContributeurs)
    //let jsonListe = JSON.stringify(listeContributeurs)
    //console.log('jsonListe : ', jsonListe)

    res.render('home.html', {contribTitle : contribTitle, lesContributeurs : listeContributeurs})
});
*/

//GESTION DES STATUS CODE---------------------------------------------

//GESTION ERREURS 404, erreur du client
app.use( (req, res, next) => {
    res.setHeader('Content-Type', 'text/plain');
    //const err = new Error("Not Found");
    //err.status = 404;
    //next(err);
    console.log('Page introuvable - erreur 404')
    res.status(404).send('Page introuvable ! Erreur 404...')
});


//GESTION 501 Not Implemented, all other requests are not implemented.
app.use((req, res) => {
   res.status(501);
   res.end('Not implemented')
});

//port localhost
app.listen(PORT, ()=>{
  console.log('Serveur sur port : ',PORT)
});

//on exporte le module app
module.exports = app;
