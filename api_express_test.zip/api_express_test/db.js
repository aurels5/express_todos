const db = require('sqlite')

db.open('bdd_express.db').then(()=>{
  Promise.all([
    db.run("CREATE TABLE IF NOT EXISTS `users` (`pseudo`, `email`, `firstname`, `lastname`, `createdAt`, `updatedAt`,	`pwd`, `teamId`, `id` INTEGER PRIMARY KEY AUTOINCREMENT)"),
    db.run("CREATE TABLE IF NOT EXISTS `sessions` (`userId`, `accessToken`, `createdAt`, `expiresAt`)"),
    db.run("CREATE TABLE IF NOT EXISTS `todos` (`userId`, `title`, `message`, `createdAt`, `updatedAt`, `completedAt`, `id` PRIMARY KEY AUTOINCREMENT)"),
    //db.run("CREATE TABLE IF NOT EXISTS `teams` (`teamName` UNIQUE, `description` , `id` INTEGER PRIMARY KEY AUTOINCREMENT)"),
  ]).then(()=>{
    console.log('Database is ready !')
  }).catch((err) => {
    console.log('An error happend (db)')
  })
})

module.exports = db;
